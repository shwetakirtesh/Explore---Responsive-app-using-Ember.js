import Ember from 'ember';

var placesController = Ember.ArrayController.extend({
init:function(){
//alert(this.get('fetchValue'));
}
  /*actions: {
    gotoMaps: function(params) {
		this.transitionTo('maps', params.lat);
		 }
  }
*/
 
});


export default placesController;
