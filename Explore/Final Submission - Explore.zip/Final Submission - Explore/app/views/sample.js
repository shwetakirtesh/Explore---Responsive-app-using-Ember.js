import Ember from 'ember';

var view = Ember.View.create({
  templateName: 'places',
  name: "Bob"
});

export default view;